import React, { useEffect, useState } from 'react';
import { Field, BurnEvent } from '../../types';
import { executeFirmsAudit, generateNonBurnCertificate } from '../../utils/spatialVerification';
import { CarbonCertificate } from './CarbonCertificate';
import { supabase } from '../../lib/supabase';
import { 
  Satellite, 
  ShieldCheck, 
  Flame, 
  CheckCircle2, 
  Award, 
  FileText, 
  Sparkles, 
  AlertCircle,
  ExternalLink,
  Layers,
  RefreshCw,
  Loader2
} from 'lucide-react';

interface SatelliteAuditProps {
  fields: Field[];
  demoMode: boolean;
  fireEvents: BurnEvent[];
}

/** Convert a raw NASA FIRMS CSV-parsed observation into a BurnEvent. */
function firmsObsToBurnEvent(
  obs: Record<string, unknown>,
  index: number,
  matchedFieldId: string | null,
): BurnEvent {
  const satelliteName = String(obs.satellite || '').trim().toUpperCase();
  const satellite: BurnEvent['satellite'] =
    satelliteName.includes('NOAA21') || satelliteName.includes('NOAA-21')
      ? 'VIIRS NOAA-21'
      : satelliteName.includes('NOAA20') || satelliteName.includes('NOAA-20')
        ? 'VIIRS NOAA-20'
        : 'VIIRS Suomi-NPP';

  return {
    id: `FIRMS-LIVE-${Date.now()}-${index}`,
    firms_point: {
      lat: Number(obs.latitude),
      lng: Number(obs.longitude),
    },
    detected_at: String(obs.acq_datetime || obs.acq_date || new Date().toISOString()),
    confidence: Number(obs.confidence) || 0,
    brightness_temp_kelvin: Number(obs.bright_ti4 || obs.brightness || 0),
    satellite,
    matched_field_id: matchedFieldId,
    nearest_village: '',
    is_registered_customer: Boolean(matchedFieldId),
  };
}

/**
 * Fetch live FIRMS observations per registered field.
 * Each field is queried with its own polygon so a detection in a neighbouring
 * field/buffer is never presented as a detection inside another customer's field.
 */
async function fetchLiveFirmsEvents(fields: Field[]): Promise<{ events: BurnEvent[]; error: string | null }> {
  if (fields.length === 0) return { events: [], error: null };

  let authHeader: Record<string, string> = {};
  if (supabase) {
    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;
    if (token) authHeader = { Authorization: `Bearer ${token}` };
  }

  const results = await Promise.allSettled(fields.map(async (field) => {
    const response = await fetch('/api/firms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeader },
      body: JSON.stringify({
        field: {
          lat: field.center.lat,
          lng: field.center.lng,
          geometry: field.geometry,
        },
        radius_km: 25,
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(String(body.error || `FIRMS API returned ${response.status}`));
    }

    const data = await response.json();
    // Only matched_observations are field-level detections. The broader
    // observations array is deliberately not used for registered-field claims.
    const observations: Record<string, unknown>[] = data.matched_observations ?? [];
    return observations.map((obs, index) => firmsObsToBurnEvent(obs, index, field.id));
  }));

  const events: BurnEvent[] = [];
  const errors: string[] = [];
  results.forEach((result) => {
    if (result.status === 'fulfilled') events.push(...result.value);
    else errors.push(result.reason instanceof Error ? result.reason.message : 'FIRMS request failed');
  });

  if (errors.length === fields.length) {
    return { events: [], error: errors[0] || 'FIRMS request failed' };
  }
  if (errors.length > 0) {
    return { events, error: `${errors.length} of ${fields.length} field FIRMS queries failed` };
  }
  return { events, error: null };
}

export const SatelliteAudit: React.FC<SatelliteAuditProps> = ({
  fields,
  demoMode,
  fireEvents: demoFireEvents,
}) => {
  const [liveEvents, setLiveEvents] = useState<BurnEvent[]>([]);
  const [firmsLoading, setFirmsLoading] = useState(false);
  const [firmsError, setFirmsError] = useState<string | null>(null);
  const [lastFetched, setLastFetched] = useState<Date | null>(null);

  const fetchFirms = async () => {
    if (demoMode) return;
    setFirmsLoading(true);
    setFirmsError(null);
    const { events, error } = await fetchLiveFirmsEvents(fields);
    setLiveEvents(events);
    setFirmsError(error);
    if (!error) setLastFetched(new Date());
    setFirmsLoading(false);
  };

  useEffect(() => {
    void fetchFirms();
    // Refresh every 10 minutes automatically
    const interval = window.setInterval(() => void fetchFirms(), 10 * 60 * 1000);
    return () => window.clearInterval(interval);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demoMode, fields.length]);

  // Use live events in live mode, demo mock events in demo mode
  const fireEvents = demoMode ? demoFireEvents : liveEvents;
  const auditReport = executeFirmsAudit(fields, fireEvents);
  const [selectedFieldForCert, setSelectedFieldForCert] = useState<Field | null>(null);

  const handleOpenCertificate = (fieldId: string) => {
    const f = fields.find((item) => item.id === fieldId);
    if (f) {
      setSelectedFieldForCert(f);
    }
  };

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto p-2">

      {/* Live FIRMS status bar — only shown in live mode */}
      {!demoMode && (
        <div className={`flex items-center justify-between gap-3 rounded-xl px-4 py-2.5 border text-xs ${
          firmsError
            ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
            : firmsLoading
            ? 'bg-slate-900/60 border-slate-700 text-slate-300'
            : liveEvents.length > 0
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
            : 'bg-slate-900/60 border-slate-700 text-slate-400'
        }`}>
          <div className="flex items-center gap-2">
            {firmsLoading
              ? <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
              : firmsError
              ? <AlertCircle className="w-4 h-4 text-amber-400" />
              : <Satellite className="w-4 h-4 text-emerald-400" />
            }
            <span className="font-semibold">
              {firmsLoading
                ? 'Fetching live NASA FIRMS VIIRS observations…'
                : firmsError
                ? `FIRMS unavailable: ${firmsError}`
                : liveEvents.length > 0
                ? `${liveEvents.length} live thermal observation(s) loaded from NASA FIRMS`
                : 'NASA FIRMS: no observations returned for this area/period'
              }
            </span>
            {lastFetched && !firmsLoading && (
              <span className="text-slate-500 font-mono">
                · last fetched {lastFetched.toLocaleTimeString()}
              </span>
            )}
          </div>
          <button
            onClick={() => void fetchFirms()}
            disabled={firmsLoading}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${firmsLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      )}

      {/* Top Banner: The Money Shot Pitch Framing */}
      <div className="glass-panel-emerald p-5">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/30">
              <Satellite className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-lg text-white font-['Outfit']">
                  Verification & Evidence Layer
                </h3>
                <span className="badge badge-emerald text-xs">
                  {demoMode ? 'Synthetic observation demo' : auditReport.dataAvailability === 'NO_OBSERVATIONS' ? 'Awaiting observations' : 'Observation review'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                We intersect registered field polygons with available remote-sensing observations and operational evidence. A missing detection is not absolute proof of no burning, and impact or registry claims remain gated by methodology and verification.
              </p>
            </div>
          </div>

          <div className="bg-slate-900/90 border border-emerald-500/40 px-4 py-3 rounded-xl flex items-center gap-3 shrink-0">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Observation coverage</span>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {auditReport.complianceRate}%
              </div>
            </div>
            <ShieldCheck className="w-7 h-7 text-emerald-400" />
          </div>
        </div>

        {/* Real NASA FIRMS Geospatial Thermal Sensor Visual */}
        <div className="mt-4 rounded-xl overflow-hidden border border-emerald-500/30 relative max-h-56 bg-slate-950">
          <img 
            src="/images/satellite_firms.jpg" 
            alt="Remote-sensing evidence illustration"
            className="w-full h-52 object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                NASA FIRMS NOAA-21 VIIRS 375m NRT SENSOR
              </span>
              <p className="text-xs font-bold text-white mt-1">
                {auditReport.dataAvailability === 'NO_OBSERVATIONS' ? 'No remote-sensing observations are currently available for field screening' : `Matched ${auditReport.cleanFieldsCount} field(s) without a detected fire point in the supplied observations`}
              </p>
            </div>
            <div className="text-right hidden sm:block">
              <span className="text-xs font-mono text-emerald-400 font-bold block">{demoMode ? 'Synthetic demo only' : auditReport.dataAvailability === 'NO_OBSERVATIONS' ? 'No observation proof' : 'Not a registry certificate'}</span>
              <span className="text-[10px] text-slate-400">No registry issuance</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Quantitative Proof Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="glass-panel p-4 border-emerald-500/30">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Customer Fires</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono">
            {auditReport.firesInRegisteredFields}{' '}
            <span className="text-xs text-emerald-300 font-normal">Fires (0%)</span>
          </div>
          <p className="text-[11px] text-emerald-400/90 mt-1 font-semibold">
            No-fire observations do not equal absolute non-burn proof
          </p>
        </div>

        <div className="glass-panel p-4 border-red-500/30">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Neighbor Fire Storm</span>
            <Flame className="w-4 h-4 text-red-500 animate-pulse" />
          </div>
          <div className="text-2xl font-extrabold text-red-400 font-mono">
            {auditReport.firesInSurroundingBuffer}{' '}
            <span className="text-xs text-slate-400 font-normal">Thermal Points</span>
          </div>
          <p className="text-[11px] text-red-400/90 mt-1 font-semibold">
            {demoMode ? 'Synthetic demo observations' : 'Only provider-returned observations are shown'}
          </p>
        </div>

        <div className="glass-panel p-4 border-cyan-500/30">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Emissions Avoided</span>
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-cyan-300 font-mono">
            {auditReport.co2eAvoided}{' '}
            <span className="text-xs text-slate-400 font-normal">t CO₂e</span>
          </div>
          <p className="text-[11px] text-cyan-400/90 mt-1 font-semibold">
            + {auditReport.pm25Prevented === 0 ? 'Not calculated' : `${auditReport.pm25Prevented} kg PM2.5 prevented`}
          </p>
        </div>

        <div className="glass-panel p-4 border-amber-500/30">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Carbon Credit Claim</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-amber-300 font-mono">
            {auditReport.carbonCreditValueInr === 0 ? '—' : `₹${auditReport.carbonCreditValueInr.toLocaleString()}`}
          </div>
          <p className="text-[11px] text-amber-400/90 mt-1 font-semibold">
            Methodology not configured
          </p>
        </div>
      </div>

      {/* Spatial Audit Table */}
      <div className="glass-panel p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            <h4 className="font-bold text-sm text-white">
              Field-Level Spatial Verification Ledger (ST_Contains Audit)
            </h4>
          </div>
          <span className="text-xs text-slate-400">
            {demoMode ? 'Synthetic observation stream' : 'Provider observations only when configured'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-900/80 text-slate-400 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Khasra #</th>
                <th className="py-2.5 px-3">Farmer & Village</th>
                <th className="py-2.5 px-3">Acreage</th>
                <th className="py-2.5 px-3">FIRMS Fires In Polygon</th>
                <th className="py-2.5 px-3">Operational / remote-sensing evidence</th>
                <th className="py-2.5 px-3">Audit Outcome</th>
                <th className="py-2.5 px-3 text-right">Certificate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {fields.map((field) => {
                return (
                  <tr key={field.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 px-3 font-bold text-white font-mono">
                      {field.khasra_no}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-200">{field.farmer_name}</div>
                      <div className="text-[11px] text-slate-400">{field.village}, {field.block}</div>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-200">
                      {field.acreage} ac
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{auditReport.dataAvailability === 'NO_OBSERVATIONS' ? 'Not assessed' : `${auditReport.auditResults.find((result) => result.fieldId === field.id)?.firesInsideCount ?? 0} fire point(s)`}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-mono text-cyan-300">{demoMode ? 'Illustrative' : 'Not available'}</span>
                      <span className="text-[10px] text-slate-500 block">{demoMode ? 'Synthetic demo value' : 'Awaiting evidence'}</span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="badge badge-emerald text-[10px]">
                        {demoMode ? 'DEMO / ILLUSTRATIVE' : field.status === 'VERIFIED_NON_BURN' ? 'INTERNAL VERIFIED' : 'NOT VERIFIED'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleOpenCertificate(field.id)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-emerald-600 hover:text-white text-emerald-300 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
                      >
                        View verification record
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* The 4 Inputs Architecture Diagram for Judges */}
      <div className="glass-panel p-4 bg-slate-950/60 flex flex-col gap-3">
        <h4 className="font-bold text-xs uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-emerald-400" />
          <span>Why This Survives Cross-Examination: The 4-Input Defense Layer</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <div className="text-emerald-400 font-bold mb-1">1. Registered Polygons</div>
            <p className="text-slate-400 text-[11px]">
              Field boundaries carry a source and verification state; manually drawn geometry is not treated as authoritative cadastral truth.
            </p>
          </div>

          <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <div className="text-emerald-400 font-bold mb-1">2. NASA FIRMS VIIRS</div>
            <p className="text-slate-400 text-[11px]">
              Remote-sensing observations are stored with provider/time metadata and interpreted as supporting evidence, not absolute proof.
            </p>
          </div>

          <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <div className="text-emerald-400 font-bold mb-1">3. Weighment Receipts</div>
            <p className="text-slate-400 text-[11px]">
              Evidence assets and residue lots link quantity, custody and quality information when those records exist.
            </p>
          </div>

          <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <div className="text-emerald-400 font-bold mb-1">4. UPI Payout Ledger</div>
            <p className="text-slate-400 text-[11px]">
              Payment is intentionally out of scope; production workflow state is audited without claiming money movement.
            </p>
          </div>
        </div>
      </div>

      {/* Certificate Modal */}
      {selectedFieldForCert && (
        <CarbonCertificate
          certificate={generateNonBurnCertificate(selectedFieldForCert)}
          onClose={() => setSelectedFieldForCert(null)}
        />
      )}
    </div>
  );
};
