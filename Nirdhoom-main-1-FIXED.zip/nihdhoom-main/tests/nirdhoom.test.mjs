import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const root = new URL('..', import.meta.url).pathname;
const read = file => fs.readFileSync(`${root}/${file}`, 'utf8');
const exists = file => fs.existsSync(`${root}/${file}`);

test('production entrypoint is modular and monolith-free', () => {
  const main = read('src/main.jsx');
  assert.match(main, /App\.tsx/);
  assert.ok(!exists('src/main.tsx'));
  assert.ok(!exists('nirdhoom-app.html'));
  assert.ok(!exists('nirdhoom-final.zip'));
});

test('V7.1 server-owned booking path replaces browser quote authority', () => {
  const v71 = read('supabase/migrations/202610010005_nirdhoom_booking_integrity.sql');
  const v72 = read('supabase/migrations/202610010006_nirdhoom_verification_and_settlement_integrity.sql');
  assert.match(v71, /reserve_clearance_booking_v2/);
  assert.match(v71, /server_authoritative/);
  assert.match(v72, /revoke execute on function public\.reserve_clearance_booking/);
});

test('verification cannot become authoritative without operational evidence', () => {
  const sql = read('supabase/migrations/202610010006_nirdhoom_verification_and_settlement_integrity.sql');
  assert.match(sql, /Verification requires completed job, evidence asset and residue lot/);
  assert.match(sql, /server_evidence_count/);
  assert.match(sql, /server_lot_count/);
});

test('buyer acceptance is tenant-scoped and atomically claims residue', () => {
  const sql = read('supabase/migrations/202610010006_nirdhoom_verification_and_settlement_integrity.sql');
  assert.match(sql, /b\.profile_id=auth\.uid\(\)/);
  assert.match(sql, /get diagnostics claimed = row_count/);
  assert.match(sql, /claimed <> 1/);
});

test('operational writes have role and ownership gates', () => {
  const sql = read('supabase/migrations/202610010007_nirdhoom_operational_integrity.sql');
  assert.match(sql, /prevent_self_privileged_profile/);
  assert.match(sql, /revoke insert on public\.firms_observations from authenticated/);
  assert.match(sql, /created_by=auth\.uid\(\)/);
  assert.match(sql, /operator inserts linked evidence/);
});

test('notification endpoints require dispatcher/admin authentication', () => {
  for (const file of ['api/notify/telegram.ts', 'api/notify/ivr.ts']) {
    const source = read(file);
    assert.match(source, /verifyDispatcher\(req\)/);
    assert.match(source, file.includes('telegram') ? /validChatId\(resolvedChatId\)/ : /validPhone\(to\)/);
    assert.match(source, /AbortSignal\.timeout\(10000\)/);
  }
});

test('telegram webhook requires configured secret token', () => {
  const source = read('api/notify/telegram-webhook.ts');
  assert.match(source, /TELEGRAM_WEBHOOK_SECRET/);
  assert.match(source, /Invalid webhook secret/);
  assert.match(source, /status: 503/);
});

test('payment integration remains explicitly fail-closed', () => {
  const source = read('api/payments/initiate.ts');
  assert.match(source, /status\(501\)/);
  assert.match(source, /No money movement was attempted/);
  assert.doesNotMatch(source, /status:\s*['"]PAID['"]/);
});

test('CI runs audit, tests and production build on Node 24', () => {
  const workflow = read('.github/workflows/ci.yml');
  assert.match(workflow, /node-version: 24/);
  assert.match(workflow, /npm run syntaxcheck/);
  assert.match(workflow, /npm run audit/);
  assert.match(workflow, /npm test/);
  assert.match(workflow, /npm run build/);
});

test('audit script validates the actual shipped entrypoint', () => {
  const source = read('scripts_validate.mjs');
  assert.match(source, /src\/App\.tsx/);
  assert.match(source, /no committed monolithic bundle/);
  assert.match(source, /server-owned booking RPC/);
});


test('V7.5 blocks direct booking writes and farmer field tampering', () => {
  const sql = read('supabase/migrations/202610020008_nirdhoom_client_write_integrity.sql');
  assert.match(sql, /revoke insert, update, delete on public\.bookings from authenticated/);
  assert.match(sql, /prevent_farmer_field_tampering/);
  assert.match(sql, /Protected field attributes must be changed through an authorized workflow/);
  assert.match(sql, /New farmer fields must begin in REGISTERED state with unverified boundaries/);
});

test('simulation surfaces do not claim real transactions', () => {
  assert.match(read('src/components/FieldOperator/UpiSettlementModal.tsx'), /no money movement/i);
  assert.match(read('src/components/FarmerOnboarding/FarmerOnboarding.tsx'), /Demo only/);
  assert.match(read('src/components/CarbonMarketplace/CarbonMarketplace.tsx'), /Illustrative carbon-market interface/);
});


test('demo operational data is opt-in and production starts empty', () => {
  const controller = read('src/state/useAppController.ts');
  assert.match(controller, /VITE_NIRDHOOM_DEMO_MODE === 'true'/);
  assert.match(controller, /DEMO_MODE \? INITIAL_FIELDS : \[\]/);
  assert.match(controller, /DEMO_MODE \? INITIAL_MACHINES : \[\]/);
  assert.match(controller, /DEMO_MODE \? MOCK_FIRMS_FIRE_EVENTS : \[\]/);
  assert.match(read('.env.example'), /VITE_NIRDHOOM_DEMO_MODE=false/);
});


test('live dashboard KPIs are derived from current records', () => {
  const app = read('src/App.tsx');
  assert.match(app, /const acresScheduled = fields\.reduce/);
  assert.match(app, /const totalPayoutInr = fields\.reduce/);
  assert.match(app, /acresScheduled=\{acresScheduled\}/);
  assert.doesNotMatch(app, /acresScheduled=\{88\.4\}/);
  assert.doesNotMatch(app, /totalPayoutInr=\{128150\}/);
});

test('live field normalization does not invent Punjab coordinates', () => {
  const domain = read('src/lib/domain.ts');
  assert.match(domain, /f\.center_lat \?\? f\.lat \?\? 0/);
  assert.match(domain, /f\.center_lng \?\? f\.lng \?\? 0/);
});


test('residue pooling is backed by verified lots and authenticated RPCs', () => {
  const schema = read('supabase/migrations/202610020010_nirdhoom_residue_pooling_and_research.sql');
  const security = read('supabase/migrations/202610020011_nirdhoom_residue_pooling_security_and_indexes.sql');
  const gate = read('supabase/migrations/202610020012_nirdhoom_residue_pool_verification_gate.sql');
  assert.match(schema, /buyer_demands/);
  assert.match(schema, /residue_pool_members/);
  assert.match(security, /revoke execute on function public\.join_residue_pool/);
  assert.match(gate, /VERIFIED_NON_BURN/);
});

test('operator PWA has real GPS and offline evidence primitives', () => {
  const source = read('src/components/FieldOperator/BalerPWA.tsx');
  const queue = read('src/lib/offlineEvidenceQueue.ts');
  assert.match(source, /navigator\.geolocation\.watchPosition/);
  assert.match(source, /storage\.from\('evidence'\)/);
  assert.match(source, /evidence_assets/);
  assert.match(queue, /indexedDB/);
  assert.match(queue, /SHA-256/);
});

test('verification UI cannot mint a registry-grade carbon certificate', () => {
  const source = read('src/utils/spatialVerification.ts');
  assert.match(source, /certificate_status: 'ILLUSTRATIVE_DEMO'/);
  assert.match(source, /verra_vm0042_eligible: false/);
  assert.match(source, /NOT_A_CRYPTOGRAPHIC_CERTIFICATE/);
});
