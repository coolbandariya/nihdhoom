declare const process: { env: Record<string, string | undefined> };

async function verifyDispatcher(req: any) {
  const authorization = String(req.headers?.authorization || '');
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';
  if (!token || !process.env.SUPABASE_URL || !process.env.SUPABASE_PUBLISHABLE_KEY) return false;
  try {
    const userResponse = await fetch(`${process.env.SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: process.env.SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(8000),
    });
    if (!userResponse.ok) return false;
    const user = await userResponse.json();
    const profileResponse = await fetch(
      `${process.env.SUPABASE_URL}/rest/v1/profiles?id=eq.${encodeURIComponent(user.id)}&select=role`,
      { headers: { apikey: process.env.SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(8000) },
    );
    if (!profileResponse.ok) return false;
    const profiles = await profileResponse.json();
    return ['dispatcher', 'admin'].includes(profiles?.[0]?.role);
  } catch { return false; }
}

// Telegram chat_id can be a numeric user/group ID or a @username string
function validChatId(value: unknown): value is string {
  if (typeof value !== 'string' || !value.trim()) return false;
  // Accept numeric IDs (possibly negative for groups) or @username handles
  return /^-?\d+$/.test(value.trim()) || /^@[A-Za-z][A-Za-z0-9_]{3,}$/.test(value.trim());
}

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    res.setHeader?.('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (!(await verifyDispatcher(req))) {
    return res.status(401).json({ error: 'Authenticated dispatcher/admin required' });
  }

  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) {
    return res.status(503).json({ error: 'TELEGRAM_BOT_TOKEN is not configured' });
  }

  const { chat_id, text, parse_mode } = req.body || {};

  // Resolve chat_id: use body value, fall back to default env target
  const resolvedChatId = String(chat_id || process.env.TELEGRAM_DEFAULT_CHAT_ID || '').trim();

  if (!validChatId(resolvedChatId)) {
    return res.status(400).json({
      error: 'A valid chat_id (numeric ID or @username) is required, or set TELEGRAM_DEFAULT_CHAT_ID in env',
    });
  }

  if (typeof text !== 'string' || !text.trim() || text.length > 4096) {
    return res.status(400).json({ error: 'text is required and must be 1–4096 characters' });
  }

  // parse_mode is optional — allow 'Markdown', 'MarkdownV2', 'HTML', or omit
  const allowedParseModes = ['Markdown', 'MarkdownV2', 'HTML'];
  const resolvedParseMode =
    typeof parse_mode === 'string' && allowedParseModes.includes(parse_mode)
      ? parse_mode
      : undefined;

  try {
    const payload: Record<string, unknown> = {
      chat_id: resolvedChatId,
      text: text.trim(),
    };
    if (resolvedParseMode) payload.parse_mode = resolvedParseMode;

    const response = await fetch(
      `https://api.telegram.org/bot${encodeURIComponent(botToken)}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(10000),
      },
    );

    const data = await response.json().catch(() => ({}));

    if (response.ok && data.ok) {
      return res.status(200).json({
        ok: true,
        message_id: data.result?.message_id ?? null,
        chat_id: resolvedChatId,
      });
    }

    return res.status(502).json({
      error: data.description || 'Telegram sendMessage failed',
      telegram_error_code: data.error_code ?? null,
    });
  } catch {
    return res.status(502).json({ error: 'Telegram Bot API unavailable' });
  }
}
